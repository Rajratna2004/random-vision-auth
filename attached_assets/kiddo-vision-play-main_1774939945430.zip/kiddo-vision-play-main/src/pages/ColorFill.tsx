import { useRef, useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Undo2 } from "lucide-react";
import { useGestureDetection } from "@/hooks/useGestureDetection";
import { useGameData } from "@/hooks/useGameData";
import GestureOverlay from "@/components/GestureOverlay";
import GestureCursor from "@/components/GestureCursor";
import GestureTutorial from "@/components/GestureTutorial";
import { playPop, playSuccess, playSwoosh } from "@/lib/sounds";

// ---------- Design templates ----------
interface Section {
  id: string;
  path: string;
  hintColor: string;
  label: string;
  filled: string | null;
}

interface Design {
  id: string;
  title: string;
  emoji: string;
  viewBox: string;
  sections: Section[];
}

const PALETTE = [
  "hsl(0, 80%, 55%)",
  "hsl(25, 95%, 55%)",
  "hsl(45, 100%, 50%)",
  "hsl(145, 63%, 45%)",
  "hsl(199, 89%, 48%)",
  "hsl(270, 60%, 55%)",
  "hsl(340, 82%, 55%)",
  "hsl(30, 50%, 40%)",
];

const DESIGNS: Design[] = [
  {
    id: "house",
    title: "🏠 Cozy House",
    emoji: "🏠",
    viewBox: "0 0 400 400",
    sections: [
      { id: "roof", path: "M200 40 L360 160 L40 160 Z", hintColor: PALETTE[0], label: "Roof", filled: null },
      { id: "wall", path: "M80 160 L320 160 L320 340 L80 340 Z", hintColor: PALETTE[3], label: "Wall", filled: null },
      { id: "door", path: "M170 240 L230 240 L230 340 L170 340 Z", hintColor: PALETTE[5], label: "Door", filled: null },
      { id: "window1", path: "M100 190 L150 190 L150 230 L100 230 Z", hintColor: PALETTE[4], label: "Window", filled: null },
      { id: "window2", path: "M250 190 L300 190 L300 230 L250 230 Z", hintColor: PALETTE[4], label: "Window", filled: null },
      { id: "sun", path: "M340 20 m-30,0 a30,30 0 1,0 60,0 a30,30 0 1,0 -60,0", hintColor: PALETTE[2], label: "Sun", filled: null },
    ],
  },
  {
    id: "butterfly",
    title: "🦋 Butterfly",
    emoji: "🦋",
    viewBox: "0 0 400 400",
    sections: [
      { id: "body", path: "M190 100 L210 100 L215 320 L185 320 Z", hintColor: PALETTE[7], label: "Body", filled: null },
      { id: "lwing-top", path: "M190 120 Q60 80 80 200 Q120 220 190 200 Z", hintColor: PALETTE[1], label: "Left Wing Top", filled: null },
      { id: "rwing-top", path: "M210 120 Q340 80 320 200 Q280 220 210 200 Z", hintColor: PALETTE[1], label: "Right Wing Top", filled: null },
      { id: "lwing-bot", path: "M190 200 Q100 220 100 300 Q140 330 190 280 Z", hintColor: PALETTE[6], label: "Left Wing Bottom", filled: null },
      { id: "rwing-bot", path: "M210 200 Q300 220 300 300 Q260 330 210 280 Z", hintColor: PALETTE[6], label: "Right Wing Bottom", filled: null },
      { id: "head", path: "M200 90 m-18,0 a18,18 0 1,0 36,0 a18,18 0 1,0 -36,0", hintColor: PALETTE[5], label: "Head", filled: null },
    ],
  },
  {
    id: "flower",
    title: "🌸 Flower",
    emoji: "🌸",
    viewBox: "0 0 400 400",
    sections: [
      { id: "stem", path: "M190 220 L210 220 L210 380 L190 380 Z", hintColor: PALETTE[3], label: "Stem", filled: null },
      { id: "leaf-l", path: "M190 290 Q120 270 140 320 Q160 340 190 310 Z", hintColor: PALETTE[3], label: "Left Leaf", filled: null },
      { id: "leaf-r", path: "M210 270 Q280 250 260 300 Q240 320 210 290 Z", hintColor: PALETTE[3], label: "Right Leaf", filled: null },
      { id: "petal1", path: "M200 130 Q230 60 200 20 Q170 60 200 130 Z", hintColor: PALETTE[6], label: "Top Petal", filled: null },
      { id: "petal2", path: "M200 130 Q270 110 290 150 Q260 180 200 160 Z", hintColor: PALETTE[6], label: "Right Petal", filled: null },
      { id: "petal3", path: "M200 160 Q250 220 220 250 Q190 230 200 160 Z", hintColor: PALETTE[6], label: "Bottom-R Petal", filled: null },
      { id: "petal4", path: "M200 160 Q150 220 180 250 Q210 230 200 160 Z", hintColor: PALETTE[6], label: "Bottom-L Petal", filled: null },
      { id: "petal5", path: "M200 130 Q130 110 110 150 Q140 180 200 160 Z", hintColor: PALETTE[6], label: "Left Petal", filled: null },
      { id: "center", path: "M200 145 m-20,0 a20,20 0 1,0 40,0 a20,20 0 1,0 -40,0", hintColor: PALETTE[2], label: "Center", filled: null },
    ],
  },
  {
    id: "car",
    title: "🚗 Racing Car",
    emoji: "🚗",
    viewBox: "0 0 400 300",
    sections: [
      { id: "body", path: "M60 160 L340 160 L340 220 L60 220 Z", hintColor: PALETTE[0], label: "Body", filled: null },
      { id: "roof", path: "M120 160 L160 100 L280 100 L310 160 Z", hintColor: PALETTE[0], label: "Roof", filled: null },
      { id: "windshield", path: "M165 105 L195 105 L195 155 L155 155 Z", hintColor: PALETTE[4], label: "Windshield", filled: null },
      { id: "rearwindow", path: "M230 105 L275 105 L300 155 L230 155 Z", hintColor: PALETTE[4], label: "Rear Window", filled: null },
      { id: "wheel1", path: "M120 220 m-28,0 a28,28 0 1,0 56,0 a28,28 0 1,0 -56,0", hintColor: PALETTE[7], label: "Front Wheel", filled: null },
      { id: "wheel2", path: "M280 220 m-28,0 a28,28 0 1,0 56,0 a28,28 0 1,0 -56,0", hintColor: PALETTE[7], label: "Rear Wheel", filled: null },
      { id: "headlight", path: "M335 170 L360 170 L360 200 L335 200 Z", hintColor: PALETTE[2], label: "Headlight", filled: null },
      { id: "bumper", path: "M40 195 L60 180 L60 220 L40 220 Z", hintColor: PALETTE[1], label: "Bumper", filled: null },
    ],
  },
  {
    id: "fish",
    title: "🐟 Tropical Fish",
    emoji: "🐟",
    viewBox: "0 0 400 300",
    sections: [
      { id: "body", path: "M100 150 Q200 40 320 150 Q200 260 100 150 Z", hintColor: PALETTE[1], label: "Body", filled: null },
      { id: "tail", path: "M100 150 L40 90 L40 210 Z", hintColor: PALETTE[2], label: "Tail", filled: null },
      { id: "eye", path: "M260 130 m-12,0 a12,12 0 1,0 24,0 a12,12 0 1,0 -24,0", hintColor: PALETTE[4], label: "Eye", filled: null },
      { id: "fin-top", path: "M200 95 Q220 40 250 80 L230 105 Z", hintColor: PALETTE[6], label: "Top Fin", filled: null },
      { id: "fin-bot", path: "M200 205 Q220 260 250 220 L230 195 Z", hintColor: PALETTE[6], label: "Bottom Fin", filled: null },
      { id: "stripe1", path: "M180 100 L190 100 L190 200 L180 200 Z", hintColor: PALETTE[5], label: "Stripe 1", filled: null },
      { id: "stripe2", path: "M220 85 L230 85 L230 215 L220 215 Z", hintColor: PALETTE[5], label: "Stripe 2", filled: null },
    ],
  },
  {
    id: "rocket",
    title: "🚀 Rocket Ship",
    emoji: "🚀",
    viewBox: "0 0 400 400",
    sections: [
      { id: "nose", path: "M200 20 L240 120 L160 120 Z", hintColor: PALETTE[0], label: "Nose Cone", filled: null },
      { id: "body", path: "M160 120 L240 120 L245 300 L155 300 Z", hintColor: PALETTE[4], label: "Body", filled: null },
      { id: "window", path: "M200 170 m-20,0 a20,20 0 1,0 40,0 a20,20 0 1,0 -40,0", hintColor: PALETTE[2], label: "Window", filled: null },
      { id: "fin-l", path: "M155 250 L110 320 L155 300 Z", hintColor: PALETTE[1], label: "Left Fin", filled: null },
      { id: "fin-r", path: "M245 250 L290 320 L245 300 Z", hintColor: PALETTE[1], label: "Right Fin", filled: null },
      { id: "flame1", path: "M175 300 L200 380 L185 300 Z", hintColor: PALETTE[2], label: "Flame Left", filled: null },
      { id: "flame2", path: "M195 300 L200 390 L215 300 Z", hintColor: PALETTE[1], label: "Flame Center", filled: null },
      { id: "flame3", path: "M215 300 L200 380 L225 300 Z", hintColor: PALETTE[2], label: "Flame Right", filled: null },
    ],
  },
  {
    id: "tree",
    title: "🌳 Big Tree",
    emoji: "🌳",
    viewBox: "0 0 400 400",
    sections: [
      { id: "trunk", path: "M180 250 L220 250 L225 380 L175 380 Z", hintColor: PALETTE[7], label: "Trunk", filled: null },
      { id: "canopy1", path: "M200 30 Q100 80 120 170 Q160 180 200 150 Q240 180 280 170 Q300 80 200 30 Z", hintColor: PALETTE[3], label: "Top Canopy", filled: null },
      { id: "canopy2", path: "M120 170 Q80 200 100 260 Q150 270 200 250 Q250 270 300 260 Q320 200 280 170 Q240 180 200 150 Q160 180 120 170 Z", hintColor: PALETTE[3], label: "Lower Canopy", filled: null },
      { id: "apple1", path: "M150 120 m-10,0 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", hintColor: PALETTE[0], label: "Apple 1", filled: null },
      { id: "apple2", path: "M240 140 m-10,0 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", hintColor: PALETTE[0], label: "Apple 2", filled: null },
      { id: "apple3", path: "M190 200 m-10,0 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", hintColor: PALETTE[0], label: "Apple 3", filled: null },
    ],
  },
];

const FILL_GESTURES = [
  { emoji: "☝️", label: "Point", description: "Move cursor to a section" },
  { emoji: "✌️", label: "Peace", description: "Fill the section with selected color" },
  { emoji: "✋", label: "Open Palm", description: "Undo last color fill" },
  { emoji: "✊", label: "Fist", description: "Pause interaction" },
];

const ColorFill = () => {
  const navigate = useNavigate();
  const { saveSession } = useGameData();
  const startTime = useRef(Date.now());

  const [designIdx, setDesignIdx] = useState(0);
  const [sections, setSections] = useState<Section[]>(() => DESIGNS[0].sections.map((s) => ({ ...s })));
  const [selectedColor, setSelectedColor] = useState(PALETTE[0]);
  const [hoveredSection, setHoveredSection] = useState<string | null>(null);
  const [showTutorial, setShowTutorial] = useState(false);
  const [completed, setCompleted] = useState(false);

  // Undo history: stores section id that was last filled
  const undoStack = useRef<{ id: string; prevColor: string | null }[]>([]);

  const svgRef = useRef<SVGSVGElement>(null);
  const sectionRefs = useRef<Map<string, SVGPathElement>>(new Map());
  const gestureCallbackRef = useRef<((g: string) => void) | null>(null);
  const lastSelectTime = useRef(0);

  const {
    videoRef, canvasRef: gestureCanvasRef, currentHand,
    isLoading, isReady, error, cameraActive,
    startGestureDetection, stopCamera,
  } = useGestureDetection({
    onGesture: (g) => gestureCallbackRef.current?.(g),
  });

  const loadDesign = useCallback((idx: number) => {
    setDesignIdx(idx);
    setSections(DESIGNS[idx].sections.map((s) => ({ ...s })));
    setCompleted(false);
    setHoveredSection(null);
    undoStack.current = [];
  }, []);

  const handleUndo = useCallback(() => {
    const last = undoStack.current.pop();
    if (!last) return;
    playSwoosh();
    setSections((prev) =>
      prev.map((s) => (s.id === last.id ? { ...s, filled: last.prevColor } : s))
    );
    setCompleted(false);
  }, []);

  // Fill a section and push to undo stack
  const fillSection = useCallback((sectionId: string, color: string) => {
    playPop();
    setSections((prev) => {
      const section = prev.find((s) => s.id === sectionId);
      if (section) {
        undoStack.current.push({ id: sectionId, prevColor: section.filled });
      }
      return prev.map((s) => (s.id === sectionId ? { ...s, filled: color } : s));
    });
  }, []);

  // Check completion
  useEffect(() => {
    const allFilled = sections.every((s) => s.filled !== null);
    if (allFilled && !completed) {
      setCompleted(true);
      playSuccess();
      const dur = Math.floor((Date.now() - startTime.current) / 1000);
      const correctCount = sections.filter((s) => s.filled === s.hintColor).length;
      saveSession({ game_type: "colorfill", score: correctCount, duration_seconds: dur, completed: true });
    }
  }, [sections, completed, saveSession]);

  // Hover detection via gesture pointer
  useEffect(() => {
    if (!cameraActive || !svgRef.current) return;
    const px = currentHand.x * window.innerWidth;
    const py = currentHand.y * window.innerHeight;

    let found: string | null = null;
    sectionRefs.current.forEach((el, id) => {
      const r = el.getBoundingClientRect();
      if (px >= r.left && px <= r.right && py >= r.top && py <= r.bottom) {
        found = id;
      }
    });
    setHoveredSection(found);
  }, [currentHand, cameraActive]);

  // Gesture actions
  useEffect(() => {
    gestureCallbackRef.current = (g: string) => {
      const now = Date.now();
      if (g === "peace" && hoveredSection) {
        if (now - lastSelectTime.current < 600) return;
        lastSelectTime.current = now;
        fillSection(hoveredSection, selectedColor);
      } else if (g === "open_palm") {
        handleUndo();
      }
    };
  }, [hoveredSection, selectedColor, fillSection, handleUndo]);

  // Color selection via gesture over palette
  const paletteRefs = useRef<Map<number, HTMLButtonElement>>(new Map());
  useEffect(() => {
    if (!cameraActive) return;
    const px = currentHand.x * window.innerWidth;
    const py = currentHand.y * window.innerHeight;
    paletteRefs.current.forEach((el, idx) => {
      const r = el.getBoundingClientRect();
      if (px >= r.left && px <= r.right && py >= r.top && py <= r.bottom) {
        if (currentHand.gesture === "peace") {
          setSelectedColor(PALETTE[idx]);
        }
      }
    });
  }, [currentHand, cameraActive]);

  const handleToggleCamera = async () => {
    if (cameraActive) { stopCamera(); }
    else { setShowTutorial(true); }
  };

  const handleTutorialDismiss = async () => {
    setShowTutorial(false);
    await startGestureDetection();
  };

  const handleSectionClick = (id: string) => {
    if (cameraActive) return;
    fillSection(id, selectedColor);
  };

  // Save on leave
  useEffect(() => {
    return () => {
      const dur = Math.floor((Date.now() - startTime.current) / 1000);
      if (dur > 5) {
        saveSession({ game_type: "colorfill", score: 0, duration_seconds: dur, completed: false });
      }
    };
  }, [saveSession]);

  const design = DESIGNS[designIdx];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-4 p-4 z-10">
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => navigate("/games")} className="p-3 rounded-full bg-muted/80 backdrop-blur-sm">
          <ArrowLeft size={24} />
        </motion.button>
        <h1 className="text-2xl md:text-3xl font-display text-foreground">🎨 {design.title}</h1>

        {/* Undo button */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={handleUndo}
          disabled={undoStack.current.length === 0}
          className="p-3 rounded-full bg-muted/80 backdrop-blur-sm disabled:opacity-30"
          title="Undo last fill"
        >
          <Undo2 size={22} />
        </motion.button>

        {cameraActive && (
          <span className="ml-auto text-sm bg-kiddo-green/20 text-kiddo-green px-3 py-1 rounded-full font-bold backdrop-blur-sm">
            ☝️ Point • ✌️ Fill • ✋ Undo
          </span>
        )}
      </div>

      {/* Design picker */}
      <div className="flex gap-2 px-4 pb-2 overflow-x-auto">
        {DESIGNS.map((d, i) => (
          <motion.button
            key={d.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => loadDesign(i)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
              designIdx === i ? "bg-primary text-primary-foreground shadow-lg" : "bg-muted text-muted-foreground"
            }`}
          >
            {d.emoji} {d.title}
          </motion.button>
        ))}
      </div>

      {/* Canvas area */}
      <div className="flex-1 flex flex-col md:flex-row gap-4 px-4 pb-4">
        {/* SVG drawing */}
        <div className="flex-1 bg-card rounded-3xl border-4 border-primary/30 shadow-lg flex items-center justify-center relative overflow-hidden">
          <svg ref={svgRef} viewBox={design.viewBox} className="w-full h-full max-h-[60vh]">
            {sections.map((s) => (
              <path
                key={s.id}
                ref={(el) => { if (el) sectionRefs.current.set(s.id, el); }}
                d={s.path}
                fill={s.filled || "hsl(0,0%,95%)"}
                stroke={hoveredSection === s.id ? "hsl(var(--primary))" : "hsl(0,0%,30%)"}
                strokeWidth={hoveredSection === s.id ? 4 : 2}
                className="cursor-pointer transition-all duration-150"
                onClick={() => handleSectionClick(s.id)}
              />
            ))}
          </svg>

          <AnimatePresence>
            {completed && (
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm"
              >
                <div className="text-center">
                  <div className="text-6xl mb-4">🎉</div>
                  <h2 className="text-3xl font-display text-foreground">Beautiful!</h2>
                  <p className="text-muted-foreground mt-2">
                    {sections.filter((s) => s.filled === s.hintColor).length}/{sections.length} colors matched!
                  </p>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => loadDesign((designIdx + 1) % DESIGNS.length)}
                    className="mt-4 kiddo-btn kiddo-gradient-sky text-primary-foreground text-lg"
                  >
                    Next Design →
                  </motion.button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Palette + hint sidebar */}
        <div className="md:w-64 flex md:flex-col gap-3">
          <div className="bg-card rounded-2xl p-4 shadow-lg flex-1">
            <h3 className="text-sm font-bold text-muted-foreground mb-3">🎨 Colors</h3>
            <div className="grid grid-cols-4 gap-2">
              {PALETTE.map((c, i) => (
                <motion.button
                  key={c}
                  ref={(el) => { if (el) paletteRefs.current.set(i, el); }}
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.85 }}
                  onClick={() => { setSelectedColor(c); playSwoosh(); }}
                  className={`w-10 h-10 rounded-full border-3 transition-all ${
                    selectedColor === c ? "border-foreground ring-2 ring-ring scale-110" : "border-transparent"
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          <div className="bg-card rounded-2xl p-4 shadow-lg flex-1">
            <h3 className="text-sm font-bold text-muted-foreground mb-3">💡 Hints</h3>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {sections.map((s) => (
                <div key={s.id} className="flex items-center gap-2 text-xs">
                  <div className="w-4 h-4 rounded-full border border-foreground/20" style={{ backgroundColor: s.hintColor }} />
                  <span className={`font-medium ${s.filled ? "text-muted-foreground line-through" : "text-foreground"}`}>
                    {s.label}
                  </span>
                  {s.filled === s.hintColor && <span className="text-kiddo-green">✓</span>}
                  {s.filled && s.filled !== s.hintColor && <span className="text-destructive">✗</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <GestureOverlay
        videoRef={videoRef}
        canvasRef={gestureCanvasRef}
        cameraActive={cameraActive}
        isLoading={isLoading}
        isReady={isReady}
        error={error}
        onToggleCamera={handleToggleCamera}
        gesture={currentHand.gesture}
      />
      <GestureCursor x={currentHand.x} y={currentHand.y} gesture={currentHand.gesture} visible={cameraActive} />

      {showTutorial && (
        <GestureTutorial onDismiss={handleTutorialDismiss} gestures={FILL_GESTURES} />
      )}
    </div>
  );
};

export default ColorFill;
