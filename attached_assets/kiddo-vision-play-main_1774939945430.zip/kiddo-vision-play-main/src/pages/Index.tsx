import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Paintbrush, Puzzle, Brain, Palette, BarChart3, Settings, Calculator, Hash, Lightbulb, Volume2 } from "lucide-react";
import heroBanner from "@/assets/hero-banner.jpg";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-[60vh] min-h-[400px] flex items-center justify-center overflow-hidden">
        <img
          src={heroBanner}
          alt="KiddoVision - Fun Learning"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" />
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", duration: 0.8 }}
          className="relative z-10 text-center px-4"
        >
          <h1 className="text-5xl md:text-7xl font-display text-kiddo-blue text-kiddo-shadow drop-shadow-lg">
            KiddoVision
          </h1>
          <p className="mt-2 text-xl md:text-2xl font-body font-bold text-foreground/80">
            ✨ Learn, Play & Grow! ✨
          </p>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => navigate("/games")}
            className="kiddo-btn kiddo-gradient-sky text-primary-foreground mt-6 text-2xl"
          >
            🎮 Let's Play!
          </motion.button>
        </motion.div>
      </section>

      {/* Quick Access Cards */}
      <section className="px-4 py-8 max-w-5xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          <GameQuickCard
            icon={<Paintbrush size={40} />}
            label="Draw"
            color="bg-kiddo-orange"
            delay={0.1}
            onClick={() => navigate("/draw")}
          />
          <GameQuickCard
            icon={<Puzzle size={40} />}
            label="Match"
            color="bg-kiddo-green"
            delay={0.2}
            onClick={() => navigate("/match")}
          />
          <GameQuickCard
            icon={<Brain size={40} />}
            label="Memory"
            color="bg-kiddo-purple"
            delay={0.3}
            onClick={() => navigate("/memory")}
          />
          <GameQuickCard
            icon={<Palette size={40} />}
            label="Color Fill"
            color="bg-kiddo-pink"
            delay={0.4}
            onClick={() => navigate("/colorfill")}
          />
          <GameQuickCard
            icon={<Calculator size={40} />}
            label="Math"
            color="bg-kiddo-yellow"
            delay={0.5}
            onClick={() => navigate("/mathquiz")}
          />
          <GameQuickCard
            icon={<Hash size={40} />}
            label="Count"
            color="bg-kiddo-cyan"
            delay={0.6}
            onClick={() => navigate("/counting")}
          />
          <GameQuickCard
            icon={<Lightbulb size={40} />}
            label="Puzzles"
            color="bg-kiddo-orange"
            delay={0.7}
            onClick={() => navigate("/brainpuzzles")}
          />
          <GameQuickCard
            icon={<Volume2 size={40} />}
            label="Quiz"
            color="bg-kiddo-pink"
            delay={0.8}
            onClick={() => navigate("/verbalquiz")}
          />
          <GameQuickCard
            icon={<BarChart3 size={40} />}
            label="Progress"
            color="bg-kiddo-cyan"
            delay={0.9}
            onClick={() => navigate("/progress")}
          />
          <GameQuickCard
            icon={<Settings size={40} />}
            label="Parents"
            color="bg-kiddo-green"
            delay={1.0}
            onClick={() => navigate("/parent")}
          />
        </div>
      </section>
    </div>
  );
};

const GameQuickCard = ({
  icon,
  label,
  color,
  delay,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  color: string;
  delay: number;
  onClick: () => void;
}) => (
  <motion.div
    initial={{ y: 40, opacity: 0 }}
    animate={{ y: 0, opacity: 1 }}
    transition={{ delay, type: "spring", stiffness: 200 }}
    whileHover={{ scale: 1.08, rotate: 2 }}
    whileTap={{ scale: 0.95 }}
    onClick={onClick}
    className={`kiddo-card ${color} p-6 flex flex-col items-center justify-center gap-3 text-primary-foreground min-h-[140px]`}
  >
    {icon}
    <span className="text-xl font-display">{label}</span>
  </motion.div>
);

export default Index;
