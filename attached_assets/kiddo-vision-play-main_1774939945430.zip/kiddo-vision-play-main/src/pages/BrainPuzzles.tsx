import { useState, useCallback, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Star, Volume2 } from "lucide-react";
import GestureOverlay from "@/components/GestureOverlay";
import { useGestureDetection } from "@/hooks/useGestureDetection";
import { useGameData } from "@/hooks/useGameData";
import { playSuccess, playError, playPop, playLevelComplete, playStar } from "@/lib/sounds";
import { speak } from "@/lib/tts";

type PuzzleType = "pattern" | "odd_one_out" | "match_quantity";

interface Puzzle {
  type: PuzzleType;
  question: string;
  display: string[];
  options: string[];
  correctIdx: number;
}

const PATTERN_SETS = [
  { items: ["🔴", "🔵"], answer: "🔴" },
  { items: ["🟡", "🟢", "🟡"], answer: "🟢" },
  { items: ["⭐", "🌙"], answer: "⭐" },
  { items: ["🐱", "🐶", "🐱"], answer: "🐶" },
  { items: ["🍎", "🍊"], answer: "🍎" },
  { items: ["△", "○", "△"], answer: "○" },
];

const ODD_SETS = [
  { items: ["🍎", "🍎", "🍎", "🐱"], odd: "🐱", hint: "One is not a fruit!" },
  { items: ["🔵", "🔵", "🔴", "🔵"], odd: "🔴", hint: "Which color is different?" },
  { items: ["🐶", "🐱", "🐟", "🚗"], odd: "🚗", hint: "Which is not an animal?" },
  { items: ["⭐", "⭐", "🌙", "⭐"], odd: "🌙", hint: "Which shape is different?" },
  { items: ["1", "2", "A", "3"], odd: "A", hint: "Which is not a number?" },
];

const QUANTITY_SETS = [
  { emoji: "🍎", count: 3, options: ["2", "3", "4", "5"], correctIdx: 1 },
  { emoji: "⭐", count: 5, options: ["3", "4", "5", "6"], correctIdx: 2 },
  { emoji: "🐟", count: 2, options: ["1", "2", "3", "4"], correctIdx: 1 },
  { emoji: "🌸", count: 4, options: ["2", "3", "4", "5"], correctIdx: 2 },
];

function generatePuzzle(): Puzzle {
  const type: PuzzleType = (["pattern", "odd_one_out", "match_quantity"] as const)[Math.floor(Math.random() * 3)];

  if (type === "pattern") {
    const set = PATTERN_SETS[Math.floor(Math.random() * PATTERN_SETS.length)];
    const seq: string[] = [];
    for (let i = 0; i < 5; i++) seq.push(set.items[i % set.items.length]);
    const answer = set.items[5 % set.items.length];
    const display = [...seq, "❓"];
    const opts = [...new Set([answer, ...set.items])];
    while (opts.length < 4) opts.push(["🟣", "🟠", "💎", "🌈"][opts.length]);
    const shuffled = opts.sort(() => Math.random() - 0.5);
    return {
      type,
      question: "What comes next?",
      display,
      options: shuffled,
      correctIdx: shuffled.indexOf(answer),
    };
  }

  if (type === "odd_one_out") {
    const set = ODD_SETS[Math.floor(Math.random() * ODD_SETS.length)];
    const shuffled = [...set.items].sort(() => Math.random() - 0.5);
    return {
      type,
      question: "Which one is different?",
      display: shuffled,
      options: shuffled,
      correctIdx: shuffled.indexOf(set.odd),
    };
  }

  // match_quantity
  const set = QUANTITY_SETS[Math.floor(Math.random() * QUANTITY_SETS.length)];
  const display = Array(set.count).fill(set.emoji);
  return {
    type,
    question: "How many?",
    display,
    options: set.options,
    correctIdx: set.correctIdx,
  };
}

const COLORS = ["bg-kiddo-orange", "bg-kiddo-green", "bg-kiddo-purple", "bg-kiddo-cyan"];
const TOTAL = 8;

const BrainPuzzles = () => {
  const navigate = useNavigate();
  const { saveSession } = useGameData();
  const [puzzle, setPuzzle] = useState<Puzzle>(generatePuzzle);
  const [qNum, setQNum] = useState(1);
  const [score, setScore] = useState(0);
  const [stars, setStars] = useState(0);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [hoverProgress, setHoverProgress] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const startTimeRef = useRef(Date.now());
  const hoverStartRef = useRef<number | null>(null);
  const hoverIdxRef = useRef<number | null>(null);
  const confirmedRef = useRef(false);
  const animRef = useRef(0);

  const gestureDetection = useGestureDetection({ enabled: true });
  const { currentHand, cameraActive } = gestureDetection;

  useEffect(() => { speak(puzzle.question); }, [puzzle]);

  const handleSelect = useCallback(
    (idx: number) => {
      if (feedback) return;
      setSelectedIdx(idx);
      const isCorrect = idx === puzzle.correctIdx;
      if (isCorrect) {
        playSuccess(); playStar();
        setScore(s => s + 10);
        setStars(s => s + 1);
        setFeedback("correct");
        speak("Great job!");
      } else {
        playError();
        setFeedback("wrong");
        speak("Try again!");
      }
      setTimeout(() => {
        setFeedback(null);
        setSelectedIdx(null);
        if (isCorrect) {
          if (qNum >= TOTAL) {
            setGameOver(true);
            playLevelComplete();
            speak("You're a genius!");
            saveSession({ game_type: "brain_puzzles", score: score + 10, duration_seconds: Math.round((Date.now() - startTimeRef.current) / 1000), completed: true });
          } else {
            setQNum(n => n + 1);
            setPuzzle(generatePuzzle());
          }
        }
      }, 1200);
    },
    [feedback, puzzle, qNum, score, saveSession]
  );

  // Gesture hover
  useEffect(() => {
    if (!cameraActive || feedback || currentHand.gesture !== "pointing") {
      setHoveredIdx(null); setHoverProgress(0);
      hoverStartRef.current = null; hoverIdxRef.current = null;
      return;
    }
    const optCount = puzzle.options.length;
    const idx = Math.max(0, Math.min(optCount - 1, Math.floor(currentHand.x * optCount)));
    if (idx !== hoverIdxRef.current) {
      hoverIdxRef.current = idx;
      hoverStartRef.current = performance.now();
      confirmedRef.current = false;
      setHoverProgress(0);
      playPop();
    }
    setHoveredIdx(idx);
    const tick = () => {
      if (!hoverStartRef.current || confirmedRef.current) return;
      const p = Math.min(1, (performance.now() - hoverStartRef.current) / 1500);
      setHoverProgress(p);
      if (p >= 1) { confirmedRef.current = true; handleSelect(hoverIdxRef.current!); return; }
      animRef.current = requestAnimationFrame(tick);
    };
    cancelAnimationFrame(animRef.current);
    animRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animRef.current);
  }, [currentHand.x, currentHand.gesture, cameraActive, feedback, handleSelect, puzzle.options.length]);

  if (gameOver) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center">
          <div className="text-6xl mb-4">🧠</div>
          <h1 className="text-4xl font-display text-foreground mb-4">Brain Master!</h1>
          <div className="flex justify-center gap-1 mb-4">
            {Array.from({ length: stars }).map((_, i) => (
              <motion.div key={i} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: i * 0.1 }}><Star size={32} className="text-kiddo-yellow fill-kiddo-yellow" /></motion.div>
            ))}
          </div>
          <p className="text-2xl font-body text-muted-foreground mb-6">Score: {score}</p>
          <div className="flex gap-4">
            <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => { setGameOver(false); setQNum(1); setScore(0); setStars(0); setPuzzle(generatePuzzle()); startTimeRef.current = Date.now(); }} className="kiddo-btn kiddo-gradient-sky text-primary-foreground">🔄 Again</motion.button>
            <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => navigate("/games")} className="kiddo-btn bg-muted text-foreground">🏠 Games</motion.button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 flex flex-col">
      <div className="flex items-center justify-between max-w-3xl mx-auto w-full mb-4">
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => navigate("/games")} className="p-3 rounded-full bg-muted"><ArrowLeft size={24} /></motion.button>
        <span className="text-lg font-body text-muted-foreground">{qNum}/{TOTAL}</span>
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => speak(puzzle.question)} className="p-3 rounded-full bg-muted"><Volume2 size={24} /></motion.button>
      </div>

      <div className="max-w-3xl mx-auto w-full mb-4">
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <motion.div className="h-full kiddo-gradient-candy rounded-full" animate={{ width: `${(qNum / TOTAL) * 100}%` }} />
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-3xl mx-auto w-full">
        <AnimatePresence mode="wait">
          <motion.div key={qNum} initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.8, opacity: 0 }} className="text-center w-full">
            <h2 className="text-2xl md:text-3xl font-display text-foreground mb-6">{puzzle.question}</h2>
            
            {/* Display area */}
            <div className="flex flex-wrap justify-center gap-3 mb-8 max-w-md mx-auto">
              {puzzle.display.map((item, i) => (
                <motion.span key={i} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: i * 0.08, type: "spring" }} className="text-4xl md:text-5xl">
                  {item}
                </motion.span>
              ))}
            </div>

            {/* Options */}
            <div className={`grid gap-3 max-w-lg mx-auto ${puzzle.options.length <= 3 ? "grid-cols-3" : "grid-cols-4"}`}>
              {puzzle.options.map((opt, i) => {
                const isHovered = hoveredIdx === i;
                const isSelected = selectedIdx === i;
                const isCorrectAnswer = feedback === "correct" && isSelected;
                const isWrongAnswer = feedback === "wrong" && isSelected;
                return (
                  <motion.button key={i} whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.95 }} onClick={() => !feedback && handleSelect(i)}
                    className={`relative kiddo-card p-4 md:p-6 text-3xl font-display text-primary-foreground ${isCorrectAnswer ? "bg-kiddo-green" : isWrongAnswer ? "bg-destructive" : COLORS[i % COLORS.length]}`}>
                    {isHovered && !feedback && (<div className="absolute inset-0 border-4 border-primary-foreground rounded-3xl" style={{ clipPath: `inset(0 ${(1 - hoverProgress) * 100}% 0 0)` }} />)}
                    {opt}
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      <GestureOverlay videoRef={gestureDetection.videoRef} canvasRef={gestureDetection.canvasRef} cameraActive={gestureDetection.cameraActive} isLoading={gestureDetection.isLoading} isReady={gestureDetection.isReady} error={gestureDetection.error} onToggleCamera={() => gestureDetection.cameraActive ? gestureDetection.stopCamera() : gestureDetection.startGestureDetection()} gesture={gestureDetection.currentHand.gesture} />
    </div>
  );
};

export default BrainPuzzles;
