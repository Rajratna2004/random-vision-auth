import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, RotateCcw, Star } from "lucide-react";
import { useGestureDetection } from "@/hooks/useGestureDetection";
import { useGameData } from "@/hooks/useGameData";
import GestureOverlay from "@/components/GestureOverlay";
import GestureCursor from "@/components/GestureCursor";
import GestureTutorial from "@/components/GestureTutorial";
import { playPop, playSuccess, playError } from "@/lib/sounds";

const PAIR_SETS = [
  { emoji: "🐶", label: "Dog", match: "🏠", matchLabel: "House" },
  { emoji: "🐟", label: "Fish", match: "🌊", matchLabel: "Water" },
  { emoji: "🐦", label: "Bird", match: "🌳", matchLabel: "Tree" },
  { emoji: "🐄", label: "Cow", match: "🌾", matchLabel: "Farm" },
  { emoji: "🦁", label: "Lion", match: "🏜️", matchLabel: "Savanna" },
  { emoji: "🐧", label: "Penguin", match: "❄️", matchLabel: "Ice" },
];

const MATCH_GESTURES = [
  { emoji: "☝️", label: "Point", description: "Move cursor over cards" },
  { emoji: "✌️", label: "Peace", description: "Select a card" },
  { emoji: "✊", label: "Fist", description: "Pause" },
];

const MatchPairs = () => {
  const navigate = useNavigate();
  const [pairs, setPairs] = useState(PAIR_SETS.slice(0, 4));
  const [selected, setSelected] = useState<{ side: "left" | "right"; index: number } | null>(null);
  const [matched, setMatched] = useState<Set<number>>(new Set());
  const [score, setScore] = useState(0);
  const [wrong, setWrong] = useState<string | null>(null);
  const [rightOrder, setRightOrder] = useState(PAIR_SETS.slice(0, 4));
  const startTime = useRef(Date.now());
  const { saveSession } = useGameData();
  const [showTutorial, setShowTutorial] = useState(false);
  const cardRefs = useRef<Map<string, HTMLButtonElement>>(new Map());
  const lastGestureSelect = useRef(0);

  const gestureCallbackRef = useRef<((g: string) => void) | null>(null);
  const {
    videoRef, canvasRef, currentHand, isLoading, isReady, error, cameraActive, startGestureDetection, stopCamera,
  } = useGestureDetection({
    onGesture: (g) => gestureCallbackRef.current?.(g),
  });

  const resetGame = () => {
    const shuffled = [...PAIR_SETS].sort(() => Math.random() - 0.5).slice(0, 4);
    setPairs(shuffled);
    setRightOrder([...shuffled].sort(() => Math.random() - 0.5));
    setSelected(null);
    setMatched(new Set());
    setScore(0);
    startTime.current = Date.now();
  };

  useEffect(() => { resetGame(); }, []);

  const handleSelect = useCallback((side: "left" | "right", pairIndex: number) => {
    if (matched.has(pairIndex)) return;
    if (!selected) { playPop(); setSelected({ side, index: pairIndex }); return; }
    if (selected.side === side) { playPop(); setSelected({ side, index: pairIndex }); return; }
    if (selected.index === pairIndex) {
      playSuccess();
      const newMatched = new Set([...matched, pairIndex]);
      setMatched(newMatched);
      setScore((s) => s + 1);
      setSelected(null);
      if (newMatched.size === pairs.length) {
        const dur = Math.floor((Date.now() - startTime.current) / 1000);
        saveSession({ game_type: "match_pairs", score: pairs.length, duration_seconds: dur, completed: true });
      }
    } else {
      playError();
      setWrong("Oops! Try again! 💪");
      setTimeout(() => setWrong(null), 1000);
      setSelected(null);
    }
  }, [matched, selected, pairs, saveSession]);

  // Gesture: peace sign selects the card under cursor
  useEffect(() => {
    gestureCallbackRef.current = (g: string) => {
      if (g !== "peace") return;
      const now = Date.now();
      if (now - lastGestureSelect.current < 800) return; // debounce
      lastGestureSelect.current = now;

      // Find which card the cursor is over
      const px = currentHand.x * window.innerWidth;
      const py = currentHand.y * window.innerHeight;

      cardRefs.current.forEach((el, key) => {
        const rect = el.getBoundingClientRect();
        if (px >= rect.left && px <= rect.right && py >= rect.top && py <= rect.bottom) {
          const [side, idxStr] = key.split("-");
          const idx = parseInt(idxStr, 10);
          handleSelect(side as "left" | "right", idx);
        }
      });
    };
  }, [currentHand, handleSelect]);

  const handleToggleCamera = async () => {
    if (cameraActive) { stopCamera(); } else { setShowTutorial(true); }
  };

  const handleTutorialDismiss = async () => {
    setShowTutorial(false);
    await startGestureDetection();
  };

  const setCardRef = useCallback((key: string) => (el: HTMLButtonElement | null) => {
    if (el) cardRefs.current.set(key, el);
    else cardRefs.current.delete(key);
  }, []);

  const allMatched = matched.size === pairs.length;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => navigate("/games")} className="p-3 rounded-full bg-muted">
            <ArrowLeft size={24} />
          </motion.button>
          <h1 className="text-2xl md:text-3xl font-display text-foreground">🧩 Match Pairs</h1>
          <div className="flex items-center gap-1 text-kiddo-yellow">
            <Star size={24} fill="currentColor" />
            <span className="text-xl font-bold text-foreground">{score}</span>
          </div>
        </div>

        {cameraActive && (
          <div className="text-center mb-4">
            <span className="text-sm bg-kiddo-green/20 text-kiddo-green px-3 py-1 rounded-full font-bold">
              ☝️ Point at card • ✌️ Select
            </span>
          </div>
        )}

        <AnimatePresence>
          {wrong && (
            <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0, opacity: 0 }}
              className="text-center text-2xl font-display text-accent mb-4">{wrong}</motion.div>
          )}
        </AnimatePresence>

        {allMatched ? (
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="text-center py-16">
            <div className="text-7xl mb-4">🎉</div>
            <h2 className="text-3xl font-display text-kiddo-green mb-4">Amazing Job!</h2>
            <p className="text-xl text-muted-foreground mb-6">You matched all pairs!</p>
            <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={resetGame}
              className="kiddo-btn kiddo-gradient-forest text-primary-foreground">
              <RotateCcw size={20} className="inline mr-2" /> Play Again!
            </motion.button>
          </motion.div>
        ) : (
          <div className="flex gap-6 md:gap-12 justify-center">
            <div className="flex flex-col gap-4">
              {pairs.map((p, i) => (
                <motion.button key={`l-${i}`} ref={setCardRef(`left-${i}`)} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                  onClick={() => handleSelect("left", i)} disabled={matched.has(i)}
                  className={`kiddo-card p-5 text-4xl min-w-[80px] text-center transition-all ${
                    matched.has(i) ? "opacity-40 scale-90 bg-kiddo-green/20"
                    : selected?.side === "left" && selected.index === i ? "ring-4 ring-primary bg-primary/10" : "bg-card"
                  }`}>{p.emoji}</motion.button>
              ))}
            </div>
            <div className="flex flex-col gap-4">
              {rightOrder.map((p, i) => {
                const origIdx = pairs.indexOf(p);
                return (
                  <motion.button key={`r-${i}`} ref={setCardRef(`right-${origIdx}`)} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                    onClick={() => handleSelect("right", origIdx)} disabled={matched.has(origIdx)}
                    className={`kiddo-card p-5 text-4xl min-w-[80px] text-center transition-all ${
                      matched.has(origIdx) ? "opacity-40 scale-90 bg-kiddo-green/20"
                      : selected?.side === "right" && selected.index === origIdx ? "ring-4 ring-primary bg-primary/10" : "bg-card"
                    }`}>{p.match}</motion.button>
                );
              })}
            </div>
          </div>
        )}

        <div className="text-center mt-6">
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={resetGame}
            className="kiddo-btn bg-muted text-foreground text-base">
            <RotateCcw size={16} className="inline mr-1" /> New Game
          </motion.button>
        </div>
      </div>

      <GestureOverlay videoRef={videoRef} canvasRef={canvasRef} cameraActive={cameraActive}
        isLoading={isLoading} isReady={isReady} error={error} onToggleCamera={handleToggleCamera} gesture={currentHand.gesture} />
      <GestureCursor x={currentHand.x} y={currentHand.y} gesture={currentHand.gesture} visible={cameraActive} />

      {showTutorial && (
        <GestureTutorial onDismiss={handleTutorialDismiss} gestures={MATCH_GESTURES} />
      )}
    </div>
  );
};

export default MatchPairs;
