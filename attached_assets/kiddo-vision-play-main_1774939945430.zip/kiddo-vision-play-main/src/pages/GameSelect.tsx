import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Paintbrush, Puzzle, Brain, Palette, ArrowLeft, Calculator, Hash, Lightbulb, Volume2 } from "lucide-react";

const games = [
  {
    id: "draw",
    title: "Air Drawing",
    description: "Draw letters, numbers & shapes!",
    icon: <Paintbrush size={48} />,
    gradient: "kiddo-gradient-sunset",
    path: "/draw",
    emoji: "🎨",
  },
  {
    id: "match",
    title: "Match Pairs",
    description: "Match animals, colors & shapes!",
    icon: <Puzzle size={48} />,
    gradient: "kiddo-gradient-forest",
    path: "/match",
    emoji: "🧩",
  },
  {
    id: "memory",
    title: "Memory Cards",
    description: "Find matching cards!",
    icon: <Brain size={48} />,
    gradient: "kiddo-gradient-candy",
    path: "/memory",
    emoji: "🧠",
  },
  {
    id: "colorfill",
    title: "Color Fill",
    description: "Fill shapes with colors!",
    icon: <Palette size={48} />,
    gradient: "kiddo-gradient-sky",
    path: "/colorfill",
    emoji: "🖌️",
  },
  {
    id: "mathquiz",
    title: "Math Quiz",
    description: "Solve fun math problems!",
    icon: <Calculator size={48} />,
    gradient: "kiddo-gradient-sunshine",
    path: "/mathquiz",
    emoji: "🧮",
  },
  {
    id: "counting",
    title: "Counting",
    description: "Count objects & learn numbers!",
    icon: <Hash size={48} />,
    gradient: "kiddo-gradient-forest",
    path: "/counting",
    emoji: "🔢",
  },
  {
    id: "brainpuzzles",
    title: "Brain Puzzles",
    description: "Patterns, logic & more!",
    icon: <Lightbulb size={48} />,
    gradient: "kiddo-gradient-candy",
    path: "/brainpuzzles",
    emoji: "🧩",
  },
  {
    id: "verbalquiz",
    title: "Verbal Quiz",
    description: "Listen & answer!",
    icon: <Volume2 size={48} />,
    gradient: "kiddo-gradient-sunset",
    path: "/verbalquiz",
    emoji: "🎤",
  },
];

const GameSelect = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => navigate("/")}
          className="mb-6 p-3 rounded-full bg-muted hover:bg-muted/80 transition"
        >
          <ArrowLeft size={28} />
        </motion.button>

        <motion.h1
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-4xl md:text-5xl font-display text-center text-foreground mb-8"
        >
          🎮 Pick a Game!
        </motion.h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {games.map((game, i) => (
            <motion.div
              key={game.id}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: i * 0.15, type: "spring" }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate(game.path)}
              className={`kiddo-card ${game.gradient} p-8 flex items-center gap-6 text-primary-foreground relative overflow-hidden`}
            >
              <div className="text-5xl">{game.emoji}</div>
              <div>
                <h2 className="text-2xl font-display">{game.title}</h2>
                <p className="text-lg opacity-90 font-body">{game.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GameSelect;
