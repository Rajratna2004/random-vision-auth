import { useState, useCallback, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Star, Volume2 } from "lucide-react";
import GestureOverlay from "@/components/GestureOverlay";
import { useGestureDetection } from "@/hooks/useGestureDetection";
import { useGameData } from "@/hooks/useGameData";
import { playSuccess, playError, playPop, playLevelComplete, playStar } from "@/lib/sounds";
import { speak } from "@/lib/tts";

type Difficulty = "easy" | "medium" | "hard";

interface Problem {
  question: string;
  options: number[];
  correct: number;
  visual?: string[];
}

function generateProblem(difficulty: Difficulty): Problem {
  const rand = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;

  if (difficulty === "easy") {
    const a = rand(1, 5);
    const b = rand(1, 5);
    const answer = a + b;
    const options = generateOptions(answer, 1, 10);
    return { question: `${a} + ${b} = ?`, options, correct: answer };
  } else if (difficulty === "medium") {
    const isAdd = Math.random() > 0.4;
    if (isAdd) {
      const a = rand(3, 12);
      const b = rand(1, 8);
      const answer = a + b;
      const options = generateOptions(answer, 2, 20);
      return { question: `${a} + ${b} = ?`, options, correct: answer };
    } else {
      const b = rand(1, 6);
      const a = rand(b + 1, 12);
      const answer = a - b;
      const options = generateOptions(answer, 0, 15);
      return { question: `${a} - ${b} = ?`, options, correct: answer };
    }
  } else {
    const type = rand(0, 2);
    if (type === 0) {
      const a = rand(5, 20);
      const b = rand(3, 10);
      const answer = a - b;
      const options = generateOptions(answer, 0, 20);
      return { question: `${a} - ${b} = ?`, options, correct: answer };
    } else if (type === 1) {
      const a = rand(10, 30);
      const b = rand(5, 15);
      const answer = a + b;
      const options = generateOptions(answer, 10, 50);
      return { question: `${a} + ${b} = ?`, options, correct: answer };
    } else {
      const answer = rand(1, 10);
      const blank = rand(1, answer);
      const other = answer - blank;
      const options = generateOptions(blank, 1, 10);
      return { question: `${other} + _ = ${answer}`, options, correct: blank };
    }
  }
}

function generateOptions(correct: number, min: number, max: number): number[] {
  const options = new Set<number>([correct]);
  while (options.size < 4) {
    let opt = correct + (Math.random() > 0.5 ? 1 : -1) * Math.floor(Math.random() * 4 + 1);
    if (opt < min) opt = min + Math.floor(Math.random() * 3);
    if (opt > max) opt = max - Math.floor(Math.random() * 3);
    if (opt !== correct) options.add(opt);
  }
  return shuffle([...options]);
}

function shuffle<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

const COLORS = [
  "bg-kiddo-orange",
  "bg-kiddo-green",
  "bg-kiddo-purple",
  "bg-kiddo-cyan",
];

const TOTAL_QUESTIONS = 10;

const MathQuiz = () => {
  const navigate = useNavigate();
  const { saveSession } = useGameData();
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [problem, setProblem] = useState<Problem | null>(null);
  const [questionNum, setQuestionNum] = useState(0);
  const [score, setScore] = useState(0);
  const [stars, setStars] = useState(0);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [hoverProgress, setHoverProgress] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const startTimeRef = useRef(Date.now());
  const hoverStartRef = useRef<number | null>(null);
  const hoverIdxRef = useRef<number | null>(null);
  const confirmedRef = useRef(false);
  const animRef = useRef(0);

  const gestureDetection = useGestureDetection({
    enabled: !!difficulty,
    onGesture: useCallback(() => {}, []),
  });

  const { currentHand, cameraActive } = gestureDetection;

  // Start game with difficulty
  const startGame = (diff: Difficulty) => {
    setDifficulty(diff);
    setQuestionNum(1);
    setScore(0);
    setStars(0);
    setGameOver(false);
    startTimeRef.current = Date.now();
    const p = generateProblem(diff);
    setProblem(p);
    speak(p.question.replace("_", "blank"));
  };

  const handleSelect = useCallback(
    (idx: number) => {
      if (!problem || feedback) return;
      setSelectedIdx(idx);
      const isCorrect = problem.options[idx] === problem.correct;
      if (isCorrect) {
        playSuccess();
        playStar();
        setScore((s) => s + 10);
        setStars((s) => s + 1);
        setFeedback("correct");
        speak("Great job!");
      } else {
        playError();
        setFeedback("wrong");
        speak("Try again!");
      }

      setTimeout(() => {
        setFeedback(null);
        setSelectedIdx(null);
        if (isCorrect) {
          if (questionNum >= TOTAL_QUESTIONS) {
            setGameOver(true);
            playLevelComplete();
            speak("Amazing! You finished!");
            saveSession({
              game_type: "math_quiz",
              score: score + 10,
              duration_seconds: Math.round((Date.now() - startTimeRef.current) / 1000),
              difficulty: difficulty!,
              completed: true,
            });
          } else {
            setQuestionNum((n) => n + 1);
            const p = generateProblem(difficulty!);
            setProblem(p);
            setTimeout(() => speak(p.question.replace("_", "blank")), 300);
          }
        }
      }, 1200);
    },
    [problem, feedback, questionNum, score, difficulty, saveSession]
  );

  // Gesture hover-to-select
  useEffect(() => {
    if (!cameraActive || !problem || feedback || currentHand.gesture === "none") {
      setHoveredIdx(null);
      setHoverProgress(0);
      hoverStartRef.current = null;
      hoverIdxRef.current = null;
      return;
    }

    if (currentHand.gesture === "pointing") {
      const idx = Math.floor(currentHand.x * problem.options.length);
      const clamped = Math.max(0, Math.min(problem.options.length - 1, idx));

      if (clamped !== hoverIdxRef.current) {
        hoverIdxRef.current = clamped;
        hoverStartRef.current = performance.now();
        confirmedRef.current = false;
        setHoverProgress(0);
        playPop();
      }
      setHoveredIdx(clamped);

      const tick = () => {
        if (!hoverStartRef.current || confirmedRef.current) return;
        const elapsed = performance.now() - hoverStartRef.current!;
        const progress = Math.min(1, elapsed / 1500);
        setHoverProgress(progress);
        if (progress >= 1) {
          confirmedRef.current = true;
          handleSelect(hoverIdxRef.current!);
          return;
        }
        animRef.current = requestAnimationFrame(tick);
      };
      cancelAnimationFrame(animRef.current);
      animRef.current = requestAnimationFrame(tick);
    }

    return () => cancelAnimationFrame(animRef.current);
  }, [currentHand.x, currentHand.y, currentHand.gesture, cameraActive, problem, feedback, handleSelect]);

  // Difficulty select screen
  if (!difficulty) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <motion.h1
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-4xl md:text-5xl font-display text-foreground mb-8"
        >
          🧮 Math Quiz
        </motion.h1>
        <p className="text-xl text-muted-foreground font-body mb-8">Pick your level!</p>
        <div className="flex flex-col sm:flex-row gap-4">
          {(["easy", "medium", "hard"] as Difficulty[]).map((d, i) => (
            <motion.button
              key={d}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: i * 0.15 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => startGame(d)}
              className={`kiddo-btn text-primary-foreground text-2xl min-w-[140px] ${
                d === "easy"
                  ? "kiddo-gradient-forest"
                  : d === "medium"
                  ? "kiddo-gradient-sunshine"
                  : "kiddo-gradient-sunset"
              }`}
            >
              {d === "easy" ? "🌱 Easy" : d === "medium" ? "🌟 Medium" : "🔥 Hard"}
            </motion.button>
          ))}
        </div>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => navigate("/games")}
          className="mt-8 p-3 rounded-full bg-muted hover:bg-muted/80"
        >
          <ArrowLeft size={28} />
        </motion.button>
      </div>
    );
  }

  // Game over
  if (gameOver) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="text-center"
        >
          <div className="text-6xl mb-4">🎉</div>
          <h1 className="text-4xl font-display text-foreground mb-4">Amazing!</h1>
          <div className="flex justify-center gap-1 mb-4">
            {Array.from({ length: stars }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.1 }}
              >
                <Star size={32} className="text-kiddo-yellow fill-kiddo-yellow" />
              </motion.div>
            ))}
          </div>
          <p className="text-2xl font-body text-muted-foreground mb-6">
            Score: {score} / {TOTAL_QUESTIONS * 10}
          </p>
          <div className="flex gap-4">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => { setDifficulty(null); }}
              className="kiddo-btn kiddo-gradient-sky text-primary-foreground"
            >
              🔄 Play Again
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => navigate("/games")}
              className="kiddo-btn bg-muted text-foreground"
            >
              🏠 Games
            </motion.button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between max-w-3xl mx-auto w-full mb-4">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => navigate("/games")}
          className="p-3 rounded-full bg-muted"
        >
          <ArrowLeft size={24} />
        </motion.button>
        <div className="flex items-center gap-2">
          <span className="text-lg font-body text-muted-foreground">
            {questionNum}/{TOTAL_QUESTIONS}
          </span>
          <div className="flex gap-0.5">
            {Array.from({ length: stars }).map((_, i) => (
              <Star key={i} size={20} className="text-kiddo-yellow fill-kiddo-yellow" />
            ))}
          </div>
        </div>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => problem && speak(problem.question.replace("_", "blank"))}
          className="p-3 rounded-full bg-muted"
        >
          <Volume2 size={24} />
        </motion.button>
      </div>

      {/* Progress bar */}
      <div className="max-w-3xl mx-auto w-full mb-6">
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full kiddo-gradient-sky rounded-full"
            animate={{ width: `${(questionNum / TOTAL_QUESTIONS) * 100}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="flex-1 flex flex-col items-center justify-center max-w-3xl mx-auto w-full">
        <AnimatePresence mode="wait">
          {problem && (
            <motion.div
              key={questionNum}
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -100, opacity: 0 }}
              className="w-full text-center mb-8"
            >
              <h2 className="text-5xl md:text-7xl font-display text-foreground mb-8">
                {problem.question}
              </h2>

              {/* Answer options */}
              <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto">
                {problem.options.map((opt, i) => {
                  const isHovered = hoveredIdx === i;
                  const isSelected = selectedIdx === i;
                  const isCorrectAnswer = feedback === "correct" && isSelected;
                  const isWrongAnswer = feedback === "wrong" && isSelected;

                  return (
                    <motion.button
                      key={`${questionNum}-${i}`}
                      whileHover={{ scale: 1.08 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => !feedback && handleSelect(i)}
                      className={`relative kiddo-card p-6 md:p-8 text-3xl md:text-4xl font-display text-primary-foreground overflow-hidden transition-all ${
                        isCorrectAnswer
                          ? "bg-kiddo-green ring-4 ring-kiddo-green"
                          : isWrongAnswer
                          ? "bg-destructive ring-4 ring-destructive"
                          : COLORS[i]
                      }`}
                    >
                      {/* Hover progress ring */}
                      {isHovered && !feedback && (
                        <motion.div
                          className="absolute inset-0 border-4 border-primary-foreground rounded-3xl"
                          style={{
                            clipPath: `inset(0 ${(1 - hoverProgress) * 100}% 0 0)`,
                          }}
                        />
                      )}
                      {opt}
                      {isCorrectAnswer && (
                        <motion.span
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute top-1 right-2 text-2xl"
                        >
                          ✅
                        </motion.span>
                      )}
                      {isWrongAnswer && (
                        <motion.span
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute top-1 right-2 text-2xl"
                        >
                          ❌
                        </motion.span>
                      )}
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Feedback overlay */}
        <AnimatePresence>
          {feedback === "correct" && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="fixed inset-0 flex items-center justify-center pointer-events-none z-30"
            >
              <div className="text-8xl">⭐</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <GestureOverlay
        videoRef={gestureDetection.videoRef}
        canvasRef={gestureDetection.canvasRef}
        cameraActive={gestureDetection.cameraActive}
        isLoading={gestureDetection.isLoading}
        isReady={gestureDetection.isReady}
        error={gestureDetection.error}
        onToggleCamera={() =>
          gestureDetection.cameraActive
            ? gestureDetection.stopCamera()
            : gestureDetection.startGestureDetection()
        }
        gesture={gestureDetection.currentHand.gesture}
      />
    </div>
  );
};

export default MathQuiz;
