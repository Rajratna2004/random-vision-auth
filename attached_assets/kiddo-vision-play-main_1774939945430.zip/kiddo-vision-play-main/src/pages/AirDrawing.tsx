import { useRef, useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Palette, RotateCcw } from "lucide-react";
import { useGestureDetection } from "@/hooks/useGestureDetection";
import { useGameData } from "@/hooks/useGameData";
import GestureOverlay from "@/components/GestureOverlay";
import GestureCursor from "@/components/GestureCursor";
import GestureTutorial from "@/components/GestureTutorial";
import { playSwoosh, playClear } from "@/lib/sounds";

const COLORS = [
  "hsl(0, 80%, 55%)",
  "hsl(25, 95%, 55%)",
  "hsl(45, 100%, 50%)",
  "hsl(145, 63%, 45%)",
  "hsl(199, 89%, 48%)",
  "hsl(270, 60%, 55%)",
  "hsl(340, 82%, 55%)",
  "hsl(0, 0%, 10%)",
];

const SIZES = [4, 8, 14, 22];

const DRAWING_GESTURES = [
  { emoji: "☝️", label: "Point", description: "Draw in the air" },
  { emoji: "✌️", label: "Peace", description: "Change color" },
  { emoji: "✋", label: "Open Palm", description: "Clear canvas" },
  { emoji: "✊", label: "Fist", description: "Pause drawing" },
];

const AirDrawing = () => {
  const navigate = useNavigate();
  const drawCanvasRef = useRef<HTMLCanvasElement>(null);
  const videoDisplayRef = useRef<HTMLVideoElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState(COLORS[4]);
  const [brushSize, setBrushSize] = useState(SIZES[1]);
  const lastPos = useRef<{ x: number; y: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const startTime = useRef(Date.now());
  const { saveSession } = useGameData();
  const [showTutorial, setShowTutorial] = useState(false);

  // Gesture detection
  const gestureCallbackRef = useRef<((g: string) => void) | null>(null);
  const {
    videoRef,
    canvasRef: gestureCanvasRef,
    currentHand,
    isLoading,
    isReady,
    error,
    cameraActive,
    startGestureDetection,
    stopCamera,
  } = useGestureDetection({
    onGesture: (g) => gestureCallbackRef.current?.(g),
  });

  // Mirror the camera stream to the display video element
  useEffect(() => {
    if (cameraActive && videoRef.current?.srcObject && videoDisplayRef.current) {
      videoDisplayRef.current.srcObject = videoRef.current.srcObject;
      videoDisplayRef.current.play().catch(() => {});
    } else if (!cameraActive && videoDisplayRef.current) {
      videoDisplayRef.current.srcObject = null;
    }
  }, [cameraActive, videoRef]);

  // Gesture-based drawing on overlay canvas (clamped coordinates)
  useEffect(() => {
    if (!cameraActive || !drawCanvasRef.current) return;
    const canvas = drawCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    if (currentHand.gesture === "pointing" && currentHand.landmarks) {
      const x = Math.max(0, Math.min(currentHand.x * canvas.width, canvas.width));
      const y = Math.max(0, Math.min(currentHand.y * canvas.height, canvas.height));

      if (lastPos.current) {
        ctx.beginPath();
        ctx.moveTo(lastPos.current.x, lastPos.current.y);
        ctx.lineTo(x, y);
        ctx.strokeStyle = color;
        ctx.lineWidth = brushSize;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.stroke();
      }
      lastPos.current = { x, y };
    } else {
      lastPos.current = null;
    }
  }, [currentHand, cameraActive, color, brushSize]);

  // Gesture actions: peace ✌️ = cycle color, open_palm ✋ = clear
  useEffect(() => {
    gestureCallbackRef.current = (g: string) => {
      if (g === "peace") {
        playSwoosh();
        setColor((prev) => {
          const idx = COLORS.indexOf(prev);
          return COLORS[(idx + 1) % COLORS.length];
        });
      } else if (g === "open_palm") {
        playClear();
        const canvas = drawCanvasRef.current;
        const ctx = canvas?.getContext("2d");
        if (ctx && canvas) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
      }
    };
  }, []);

  const handleToggleCamera = async () => {
    if (cameraActive) {
      stopCamera();
    } else {
      setShowTutorial(true);
    }
  };

  const handleTutorialDismiss = async () => {
    setShowTutorial(false);
    await startGestureDetection();
  };

  // Touch/mouse drawing (only when camera NOT active — fallback white canvas mode)
  const getPos = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    const canvas = drawCanvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    if ("touches" in e) {
      return { x: e.touches[0].clientX - rect.left, y: e.touches[0].clientY - rect.top };
    }
    return { x: (e as React.MouseEvent).clientX - rect.left, y: (e as React.MouseEvent).clientY - rect.top };
  }, []);

  const startDraw = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    if (cameraActive) return; // Gesture mode handles drawing
    setIsDrawing(true);
    lastPos.current = getPos(e);
  }, [getPos, cameraActive]);

  const draw = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    if (!isDrawing || cameraActive) return;
    const canvas = drawCanvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!ctx || !lastPos.current) return;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(lastPos.current.x, lastPos.current.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = color;
    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
    lastPos.current = pos;
  }, [isDrawing, color, brushSize, getPos, cameraActive]);

  const stopDraw = useCallback(() => {
    setIsDrawing(false);
    lastPos.current = null;
  }, []);

  const clearCanvas = useCallback(() => {
    const canvas = drawCanvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (ctx && canvas) {
      if (cameraActive) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      } else {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
    }
  }, [cameraActive]);

  // Canvas resize
  useEffect(() => {
    const canvas = drawCanvasRef.current;
    if (!canvas) return;
    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      canvas.width = parent.clientWidth;
      canvas.height = parent.clientHeight;
      if (!cameraActive) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
      }
    };
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, [cameraActive]);

  // Save session on leave
  useEffect(() => {
    return () => {
      const duration = Math.floor((Date.now() - startTime.current) / 1000);
      if (duration > 5) {
        saveSession({ game_type: "drawing", score: 1, duration_seconds: duration, completed: true });
      }
    };
  }, [saveSession]);

  return (
    <div className="min-h-screen bg-background flex flex-col" ref={containerRef}>
      <div className="flex items-center gap-4 p-4 relative z-10">
        <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => navigate("/games")} className="p-3 rounded-full bg-muted/80 backdrop-blur-sm">
          <ArrowLeft size={24} />
        </motion.button>
        <h1 className="text-2xl md:text-3xl font-display text-foreground">🎨 {cameraActive ? "Air Canvas" : "Drawing Canvas"}</h1>
        {cameraActive && (
          <span className="ml-auto text-sm bg-kiddo-green/20 text-kiddo-green px-3 py-1 rounded-full font-bold backdrop-blur-sm">
            ☝️ Draw • ✌️ Color • ✋ Clear • ✊ Pause
          </span>
        )}
      </div>

      {/* Main canvas area */}
      <div className="flex-1 mx-4 mb-4 rounded-3xl overflow-hidden border-4 border-kiddo-blue shadow-lg relative bg-black">
        {/* Live camera feed as background when active */}
        {cameraActive && (
          <video
            ref={videoDisplayRef}
            className="absolute inset-0 w-full h-full object-cover transform scale-x-[-1]"
            playsInline
            muted
          />
        )}

        {/* Drawing overlay canvas - transparent when camera active, white when not */}
        <canvas
          ref={drawCanvasRef}
          className={`absolute inset-0 w-full h-full touch-none ${cameraActive ? "cursor-none" : "cursor-crosshair bg-white"}`}
          onMouseDown={startDraw}
          onMouseMove={draw}
          onMouseUp={stopDraw}
          onMouseLeave={stopDraw}
          onTouchStart={startDraw}
          onTouchMove={draw}
          onTouchEnd={stopDraw}
        />

        {/* Current color indicator when in gesture mode */}
        {cameraActive && (
          <div className="absolute top-3 left-3 flex items-center gap-2 bg-card/80 backdrop-blur-sm rounded-full px-3 py-1.5 z-10">
            <div className="w-6 h-6 rounded-full border-2 border-foreground/30" style={{ backgroundColor: color }} />
            <span className="text-xs font-bold text-foreground">Brush</span>
          </div>
        )}
      </div>

      {/* Toolbar - only show full palette when camera is NOT active */}
      {!cameraActive && (
        <div className="p-4 flex flex-wrap items-center justify-center gap-3 bg-card rounded-t-3xl shadow-lg">
          <div className="flex gap-2 items-center">
            <Palette size={20} className="text-muted-foreground" />
            {COLORS.map((c) => (
              <motion.button key={c} whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.8 }} onClick={() => setColor(c)}
                className={`w-8 h-8 rounded-full border-2 transition-all ${color === c ? "border-foreground scale-110 ring-2 ring-ring" : "border-transparent"}`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
          <div className="flex gap-2 items-center ml-4">
            {SIZES.map((s) => (
              <motion.button key={s} whileTap={{ scale: 0.8 }} onClick={() => setBrushSize(s)}
                className={`rounded-full bg-foreground transition-all ${brushSize === s ? "ring-2 ring-primary" : ""}`}
                style={{ width: s + 12, height: s + 12 }}
              />
            ))}
          </div>
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={clearCanvas}
            className="ml-4 kiddo-btn bg-destructive text-destructive-foreground text-base px-4 py-2"
          >
            <RotateCcw size={18} className="inline mr-1" /> Clear
          </motion.button>
        </div>
      )}

      {/* Gesture controls */}
      <GestureOverlay
        videoRef={videoRef}
        canvasRef={gestureCanvasRef}
        cameraActive={cameraActive}
        isLoading={isLoading}
        isReady={isReady}
        error={error}
        onToggleCamera={handleToggleCamera}
        gesture={currentHand.gesture}
      />
      <GestureCursor x={currentHand.x} y={currentHand.y} gesture={currentHand.gesture} visible={cameraActive} />

      {/* Gesture Tutorial */}
      {showTutorial && (
        <GestureTutorial onDismiss={handleTutorialDismiss} gestures={DRAWING_GESTURES} />
      )}
    </div>
  );
};

export default AirDrawing;
