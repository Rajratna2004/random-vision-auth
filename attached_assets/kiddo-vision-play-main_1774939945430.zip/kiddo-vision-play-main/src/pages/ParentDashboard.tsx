import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, Shield, BarChart3, Users } from "lucide-react";
import { useGameData } from "@/hooks/useGameData";
import { useEffect, useState } from "react";

const ParentDashboard = () => {
  const navigate = useNavigate();
  const { getStats } = useGameData();
  const [sessions, setSessions] = useState<any[]>([]);

  useEffect(() => {
    getStats().then(setSessions);
  }, [getStats]);

  const totalMinutes = Math.round(sessions.reduce((sum, s) => sum + (s.duration_seconds || 0), 0) / 60);
  const todaySessions = sessions.filter((s) => s.created_at?.startsWith(new Date().toISOString().split("T")[0]));
  const todayMinutes = Math.round(todaySessions.reduce((sum, s) => sum + (s.duration_seconds || 0), 0) / 60);

  const gameTypes = ["drawing", "match_pairs", "memory"];
  const gameLevels = gameTypes.map((type) => {
    const count = sessions.filter((s) => s.game_type === type && s.completed).length;
    return { type, level: Math.min(Math.floor(count / 2) + 1, 10) };
  });

  const recentDays = Array.from(new Set(sessions.map((s) => s.created_at?.split("T")[0]))).slice(0, 5);

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => navigate("/")} className="p-3 rounded-full bg-muted">
            <ArrowLeft size={24} />
          </motion.button>
          <h1 className="text-3xl md:text-4xl font-display text-foreground">👨‍👩‍👧 Parent Zone</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="bg-card rounded-3xl p-6 shadow-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-kiddo-blue/10"><Clock size={28} className="text-kiddo-blue" /></div>
              <h2 className="text-xl font-display text-foreground">Screen Time</h2>
            </div>
            <p className="text-muted-foreground mb-4">Today: <span className="font-bold text-foreground">{todayMinutes} min</span></p>
            <div className="w-full bg-muted rounded-full h-3 mb-2">
              <div className="bg-kiddo-green h-3 rounded-full transition-all" style={{ width: `${Math.min((todayMinutes / 60) * 100, 100)}%` }} />
            </div>
            <p className="text-sm text-muted-foreground">{todayMinutes} of 60 min recommended</p>
            <p className="text-xs text-muted-foreground mt-2">Total all-time: {totalMinutes} min</p>
          </motion.div>

          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.1 }} className="bg-card rounded-3xl p-6 shadow-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-kiddo-purple/10"><BarChart3 size={28} className="text-kiddo-purple" /></div>
              <h2 className="text-xl font-display text-foreground">Learning Stats</h2>
            </div>
            <div className="space-y-3">
              {gameLevels.map((g) => (
                <div key={g.type} className="flex justify-between text-sm">
                  <span className="text-muted-foreground capitalize">{g.type.replace("_", " ")}</span>
                  <span className="font-bold text-foreground">Level {g.level}</span>
                </div>
              ))}
              <div className="text-xs text-muted-foreground mt-2">Total sessions: {sessions.length}</div>
            </div>
          </motion.div>

          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="bg-card rounded-3xl p-6 shadow-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-kiddo-green/10"><Shield size={28} className="text-kiddo-green" /></div>
              <h2 className="text-xl font-display text-foreground">Privacy & Safety</h2>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>✅ No camera images stored</li>
              <li>✅ All CV processing runs locally in browser</li>
              <li>✅ No personal data collected</li>
              <li>✅ COPPA compliant design</li>
              <li>✅ Anonymous player IDs only</li>
            </ul>
          </motion.div>

          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }} className="bg-card rounded-3xl p-6 shadow-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-kiddo-orange/10"><Users size={28} className="text-kiddo-orange" /></div>
              <h2 className="text-xl font-display text-foreground">Recent Sessions</h2>
            </div>
            <div className="space-y-2 text-sm">
              {recentDays.length === 0 ? (
                <p className="text-muted-foreground">No sessions yet — start playing!</p>
              ) : (
                recentDays.map((day) => {
                  const daySessions = sessions.filter((s) => s.created_at?.startsWith(day));
                  const dayMin = Math.round(daySessions.reduce((sum, s) => sum + (s.duration_seconds || 0), 0) / 60);
                  return (
                    <div key={day} className="flex justify-between py-1 border-b border-border last:border-0">
                      <span className="text-muted-foreground">{day}</span>
                      <span className="font-bold text-foreground">{dayMin} min ({daySessions.length} games)</span>
                    </div>
                  );
                })
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ParentDashboard;
