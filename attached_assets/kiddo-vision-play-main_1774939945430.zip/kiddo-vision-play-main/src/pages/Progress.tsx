import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Star, Trophy, Flame, Target } from "lucide-react";
import { useGameData } from "@/hooks/useGameData";
import { useEffect, useState } from "react";

const Progress = () => {
  const navigate = useNavigate();
  const { getStats } = useGameData();
  const [sessions, setSessions] = useState<any[]>([]);

  useEffect(() => {
    getStats().then(setSessions);
  }, [getStats]);

  const totalGames = sessions.length;
  const totalStars = sessions.filter((s) => s.completed).length;
  const uniqueDays = new Set(sessions.map((s) => s.created_at?.split("T")[0])).size;

  const achievements = [
    { emoji: "🌟", title: "First Star", desc: "Completed your first game!", unlocked: totalGames >= 1 },
    { emoji: "🎨", title: "Little Artist", desc: "Played 5 drawing sessions!", unlocked: sessions.filter((s) => s.game_type === "drawing").length >= 5 },
    { emoji: "🧩", title: "Puzzle Pro", desc: "Matched 3 sets!", unlocked: sessions.filter((s) => s.game_type === "match_pairs").length >= 3 },
    { emoji: "🔥", title: "On Fire", desc: "Played on 3 different days!", unlocked: uniqueDays >= 3 },
    { emoji: "🧠", title: "Sharp Mind", desc: "Memory game under 10 moves!", unlocked: sessions.some((s) => s.game_type === "memory" && s.moves && s.moves < 10) },
  ];

  const stats = [
    { label: "Games Played", value: totalGames, icon: <Target size={28} />, color: "bg-kiddo-blue" },
    { label: "Stars Earned", value: totalStars, icon: <Star size={28} />, color: "bg-kiddo-yellow" },
    { label: "Days Active", value: uniqueDays, icon: <Flame size={28} />, color: "bg-kiddo-orange" },
    { label: "Achievements", value: achievements.filter((a) => a.unlocked).length, icon: <Trophy size={28} />, color: "bg-kiddo-purple" },
  ];

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={() => navigate("/")} className="p-3 rounded-full bg-muted">
            <ArrowLeft size={24} />
          </motion.button>
          <h1 className="text-3xl md:text-4xl font-display text-foreground">📊 My Progress</h1>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          {stats.map((stat, i) => (
            <motion.div key={stat.label} initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: i * 0.1 }}
              className={`kiddo-card ${stat.color} p-6 text-primary-foreground text-center`}>
              <div className="flex justify-center mb-2">{stat.icon}</div>
              <div className="text-3xl font-display">{stat.value}</div>
              <div className="text-sm font-body opacity-90">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        <h2 className="text-2xl font-display text-foreground mb-4">🏆 Achievements</h2>
        <div className="space-y-3">
          {achievements.map((a, i) => (
            <motion.div key={a.title} initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: i * 0.1 }}
              className={`bg-card rounded-2xl p-4 flex items-center gap-4 shadow-sm ${!a.unlocked ? "opacity-40 grayscale" : ""}`}>
              <span className="text-4xl">{a.emoji}</span>
              <div>
                <h3 className="font-display text-lg text-foreground">{a.title}</h3>
                <p className="text-sm text-muted-foreground">{a.desc}</p>
              </div>
              {a.unlocked && <span className="ml-auto text-kiddo-green text-2xl">✅</span>}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Progress;
