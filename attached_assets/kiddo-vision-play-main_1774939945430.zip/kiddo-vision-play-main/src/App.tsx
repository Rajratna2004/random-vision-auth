import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import GameSelect from "./pages/GameSelect";
import AirDrawing from "./pages/AirDrawing";
import ColorFill from "./pages/ColorFill";
import MatchPairs from "./pages/MatchPairs";
import MemoryCards from "./pages/MemoryCards";
import MathQuiz from "./pages/MathQuiz";
import VisualCounting from "./pages/VisualCounting";
import BrainPuzzles from "./pages/BrainPuzzles";
import VerbalQuiz from "./pages/VerbalQuiz";
import Progress from "./pages/Progress";
import ParentDashboard from "./pages/ParentDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/games" element={<GameSelect />} />
          <Route path="/draw" element={<AirDrawing />} />
          <Route path="/colorfill" element={<ColorFill />} />
          <Route path="/match" element={<MatchPairs />} />
          <Route path="/memory" element={<MemoryCards />} />
          <Route path="/mathquiz" element={<MathQuiz />} />
          <Route path="/counting" element={<VisualCounting />} />
          <Route path="/brainpuzzles" element={<BrainPuzzles />} />
          <Route path="/verbalquiz" element={<VerbalQuiz />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/parent" element={<ParentDashboard />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
