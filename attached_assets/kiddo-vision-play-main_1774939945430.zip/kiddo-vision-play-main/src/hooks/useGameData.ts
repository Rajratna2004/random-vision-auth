import { supabase } from "@/integrations/supabase/client";
import { usePlayerId } from "./usePlayerId";
import { useCallback } from "react";

export function useGameData() {
  const playerId = usePlayerId();

  const saveSession = useCallback(
    async (data: {
      game_type: string;
      score: number;
      moves?: number;
      duration_seconds?: number;
      difficulty?: string;
      completed?: boolean;
    }) => {
      const { error } = await supabase.from("game_sessions").insert({
        player_id: playerId,
        ...data,
      });
      if (error) console.error("Save session error:", error);
    },
    [playerId]
  );

  const getStats = useCallback(async () => {
    const { data, error } = await supabase
      .from("game_sessions")
      .select("*")
      .eq("player_id", playerId)
      .order("created_at", { ascending: false });
    if (error) {
      console.error("Get stats error:", error);
      return [];
    }
    return data || [];
  }, [playerId]);

  return { playerId, saveSession, getStats };
}
