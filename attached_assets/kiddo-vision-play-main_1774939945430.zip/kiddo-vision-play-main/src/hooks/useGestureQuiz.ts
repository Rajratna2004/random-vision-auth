import { useState, useRef, useCallback, useEffect } from "react";
import { useGestureDetection, GestureType } from "./useGestureDetection";
import { playPop, playSuccess, playError, playSwoosh } from "@/lib/sounds";

interface UseGestureQuizOptions {
  optionCount: number;
  correctIndex: number;
  onSelect: (index: number) => void;
  enabled?: boolean;
  hoverDuration?: number; // ms to confirm, default 1500
}

export function useGestureQuiz({
  optionCount,
  correctIndex,
  onSelect,
  enabled = true,
  hoverDuration = 1500,
}: UseGestureQuizOptions) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [hoverProgress, setHoverProgress] = useState(0);
  const hoverStartRef = useRef<number | null>(null);
  const hoverIndexRef = useRef<number | null>(null);
  const confirmedRef = useRef(false);
  const animRef = useRef<number>(0);

  const gestureDetection = useGestureDetection({
    enabled,
    onGesture: useCallback((g: GestureType) => {
      if (g === "peace") playSwoosh();
    }, []),
  });

  const { currentHand, cameraActive } = gestureDetection;

  // Map hand position to option index
  const getHoveredOption = useCallback(
    (x: number, _y: number): number | null => {
      if (optionCount <= 0) return null;
      const idx = Math.floor(x * optionCount);
      return Math.max(0, Math.min(optionCount - 1, idx));
    },
    [optionCount]
  );

  // Hover-to-confirm loop
  useEffect(() => {
    if (!cameraActive || !enabled || currentHand.gesture === "none") {
      setHoveredIndex(null);
      setHoverProgress(0);
      hoverStartRef.current = null;
      hoverIndexRef.current = null;
      return;
    }

    if (currentHand.gesture === "pointing" || currentHand.gesture === "peace") {
      const idx = getHoveredOption(currentHand.x, currentHand.y);

      if (idx !== hoverIndexRef.current) {
        hoverIndexRef.current = idx;
        hoverStartRef.current = performance.now();
        confirmedRef.current = false;
        setHoverProgress(0);
        if (idx !== null) playPop();
      }

      setHoveredIndex(idx);

      const tick = () => {
        if (
          hoverStartRef.current === null ||
          hoverIndexRef.current === null ||
          confirmedRef.current
        )
          return;
        const elapsed = performance.now() - hoverStartRef.current;
        const progress = Math.min(1, elapsed / hoverDuration);
        setHoverProgress(progress);
        if (progress >= 1 && !confirmedRef.current) {
          confirmedRef.current = true;
          onSelect(hoverIndexRef.current);
          return;
        }
        animRef.current = requestAnimationFrame(tick);
      };
      cancelAnimationFrame(animRef.current);
      animRef.current = requestAnimationFrame(tick);
    } else if (currentHand.gesture === "open_palm") {
      // Open palm → next question (handled by parent)
    }

    return () => cancelAnimationFrame(animRef.current);
  }, [
    currentHand.x,
    currentHand.y,
    currentHand.gesture,
    cameraActive,
    enabled,
    hoverDuration,
    getHoveredOption,
    onSelect,
  ]);

  return {
    ...gestureDetection,
    hoveredIndex,
    hoverProgress,
  };
}
