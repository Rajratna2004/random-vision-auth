import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export function usePlayerId(): string {
  const [playerId, setPlayerId] = useState<string>("");

  useEffect(() => {
    let mounted = true;

    const initAuth = async () => {
      // Check for existing session first
      const { data: { session } } = await supabase.auth.getSession();

      if (session?.user?.id) {
        if (mounted) setPlayerId(session.user.id);
        return;
      }

      // Sign in anonymously
      const { data, error } = await supabase.auth.signInAnonymously();
      if (error) {
        console.error("Anonymous sign-in error:", error);
        return;
      }
      if (mounted && data.user?.id) {
        setPlayerId(data.user.id);
      }
    };

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        if (mounted && session?.user?.id) {
          setPlayerId(session.user.id);
        }
      }
    );

    initAuth();

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return playerId;
}
