import { useRef, useState, useEffect, useCallback } from "react";

export type GestureType = 
  | "pointing"      // Index finger up
  | "open_palm"     // All fingers open
  | "peace"         // Two fingers (index + middle)
  | "fist"          // Closed fist
  | "thumbs_up"     // Thumb up
  | "none";         // No hand detected

export interface HandPosition {
  x: number; // 0-1 normalized
  y: number; // 0-1 normalized
  gesture: GestureType;
  landmarks: Array<{ x: number; y: number; z: number }> | null;
}

interface UseGestureDetectionOptions {
  enabled?: boolean;
  onGesture?: (gesture: GestureType) => void;
}

// Classify gesture from hand landmarks
function classifyGesture(landmarks: Array<{ x: number; y: number; z: number }>): GestureType {
  if (!landmarks || landmarks.length < 21) return "none";

  // Finger tip and pip (base joint) indices
  const tips = [4, 8, 12, 16, 20]; // thumb, index, middle, ring, pinky
  const pips = [3, 6, 10, 14, 18];

  // Check if each finger is extended (tip higher than pip, lower y = higher on screen)
  const isExtended = tips.map((tip, i) => {
    if (i === 0) {
      // Thumb: check x distance from palm center
      return Math.abs(landmarks[tip].x - landmarks[2].x) > 0.05;
    }
    return landmarks[tip].y < landmarks[pips[i]].y;
  });

  const extendedCount = isExtended.filter(Boolean).length;

  // Fist: no fingers extended
  if (extendedCount === 0) return "fist";

  // Thumbs up: only thumb extended
  if (isExtended[0] && extendedCount === 1) return "thumbs_up";

  // Pointing: only index finger extended
  if (!isExtended[0] && isExtended[1] && !isExtended[2] && !isExtended[3] && !isExtended[4]) {
    return "pointing";
  }

  // Peace: index + middle extended
  if (isExtended[1] && isExtended[2] && !isExtended[3] && !isExtended[4]) {
    return "peace";
  }

  // Open palm: 4+ fingers extended
  if (extendedCount >= 4) return "open_palm";

  return "none";
}

export function useGestureDetection({ enabled = true, onGesture }: UseGestureDetectionOptions = {}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const handLandmarkerRef = useRef<any>(null);
  const animFrameRef = useRef<number>(0);
  const lastGestureRef = useRef<GestureType>("none");

  const [isLoading, setIsLoading] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const smoothedPos = useRef({ x: 0.5, y: 0.5 });
  const [currentHand, setCurrentHand] = useState<HandPosition>({
    x: 0.5,
    y: 0.5,
    gesture: "none",
    landmarks: null,
  });
  const [cameraActive, setCameraActive] = useState(false);

  // Combined: get camera FIRST (needs user gesture), then load MediaPipe
  const startGestureDetection = useCallback(async () => {
    console.log("startGestureDetection called, enabled:", enabled, "videoRef:", !!videoRef.current);
    if (!enabled || !videoRef.current) return;
    setIsLoading(true);
    setError(null);

    try {
      // Step 1: Request camera IMMEDIATELY in user gesture context
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 320 }, height: { ideal: 240 } },
      });
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      setCameraActive(true);
      console.log("Camera started successfully");

      // Step 2: Load MediaPipe (can be async, no gesture requirement)
      if (!handLandmarkerRef.current) {
        console.log("Loading MediaPipe...");
        const { FilesetResolver, HandLandmarker } = await import("@mediapipe/tasks-vision");

        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm"
        );

        const handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath:
              "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
            delegate: "GPU",
          },
          runningMode: "VIDEO",
          numHands: 1,
          minHandDetectionConfidence: 0.3,
          minHandPresenceConfidence: 0.3,
          minTrackingConfidence: 0.3,
        });

        handLandmarkerRef.current = handLandmarker;
        console.log("MediaPipe loaded successfully");
      }
      setIsReady(true);
    } catch (err: any) {
      console.error("Gesture detection error:", err);
      if (err.name === "NotAllowedError") {
        setError("Camera access denied. Please allow camera access for gesture controls.");
      } else {
        setError(err.message || "Failed to start gesture detection");
      }
      // Stop camera if MediaPipe failed but camera started
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((t) => t.stop());
        videoRef.current.srcObject = null;
        setCameraActive(false);
      }
    } finally {
      setIsLoading(false);
    }
  }, [enabled]);

  const stopCamera = useCallback(() => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach((t) => t.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
  }, []);

  const detectLoop = useCallback(() => {
    if (!handLandmarkerRef.current || !videoRef.current || !cameraActive) return;

    const video = videoRef.current;
    if (video.readyState >= 2) {
      const result = handLandmarkerRef.current.detectForVideo(video, performance.now());

      if (result.landmarks && result.landmarks.length > 0) {
        const lm = result.landmarks[0];
        const gesture = classifyGesture(lm);
        const indexTip = lm[8]; // Index finger tip for pointing

        // Smooth position with exponential moving average for less jitter
        const smoothing = 0.4; // lower = smoother but more lag
        smoothedPos.current.x = smoothedPos.current.x + smoothing * ((1 - indexTip.x) - smoothedPos.current.x);
        smoothedPos.current.y = smoothedPos.current.y + smoothing * (indexTip.y - smoothedPos.current.y);

        setCurrentHand({
          x: smoothedPos.current.x,
          y: smoothedPos.current.y,
          gesture,
          landmarks: lm,
        });

        if (gesture !== lastGestureRef.current && gesture !== "none") {
          lastGestureRef.current = gesture;
          onGesture?.(gesture);
        }
        if (gesture === "none") {
          lastGestureRef.current = "none";
        }
      } else {
        setCurrentHand((prev) => ({ ...prev, gesture: "none", landmarks: null }));
        lastGestureRef.current = "none";
      }

      // Draw landmarks on canvas
      if (canvasRef.current && result.landmarks?.[0]) {
        const ctx = canvasRef.current.getContext("2d");
        if (ctx) {
          ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
          const lm = result.landmarks[0];
          for (const point of lm) {
            ctx.beginPath();
            ctx.arc(
              (1 - point.x) * canvasRef.current.width,
              point.y * canvasRef.current.height,
              4,
              0,
              2 * Math.PI
            );
            ctx.fillStyle = "hsl(199, 89%, 48%)";
            ctx.fill();
          }
        }
      }
    }

    animFrameRef.current = requestAnimationFrame(detectLoop);
  }, [cameraActive, onGesture]);

  useEffect(() => {
    if (cameraActive && isReady) {
      detectLoop();
    }
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [cameraActive, isReady, detectLoop]);

  useEffect(() => {
    return () => {
      stopCamera();
      handLandmarkerRef.current?.close();
      handLandmarkerRef.current = null;
    };
  }, [stopCamera]);

  return {
    videoRef,
    canvasRef,
    currentHand,
    isLoading,
    isReady,
    error,
    cameraActive,
    startGestureDetection,
    stopCamera,
  };
}
