import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

interface GestureTutorialProps {
  onDismiss: () => void;
  gestures?: Array<{ emoji: string; label: string; description: string }>;
}

const DEFAULT_GESTURES = [
  { emoji: "☝️", label: "Point", description: "Draw or select items" },
  { emoji: "✌️", label: "Peace", description: "Change color" },
  { emoji: "✋", label: "Open Palm", description: "Clear canvas" },
  { emoji: "✊", label: "Fist", description: "Pause drawing" },
];

const GestureTutorial = ({ onDismiss, gestures = DEFAULT_GESTURES }: GestureTutorialProps) => {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
        onClick={onDismiss}
      >
        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.7, opacity: 0 }}
          transition={{ type: "spring", damping: 20 }}
          className="bg-card rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl border-2 border-primary/20 relative"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={onDismiss}
            className="absolute top-3 right-3 p-2 rounded-full bg-muted hover:bg-muted/80 transition"
          >
            <X size={20} />
          </button>

          <h2 className="text-2xl md:text-3xl font-display text-foreground text-center mb-2">
            🖐️ Hand Gestures
          </h2>
          <p className="text-muted-foreground text-center text-sm mb-6">
            Use these hand signs to control the game!
          </p>

          <div className="grid grid-cols-2 gap-4">
            {gestures.map((g, i) => (
              <motion.div
                key={g.label}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: i * 0.1 }}
                className="bg-muted rounded-2xl p-4 text-center flex flex-col items-center gap-2"
              >
                <span className="text-5xl">{g.emoji}</span>
                <span className="font-display text-foreground text-lg">{g.label}</span>
                <span className="text-xs text-muted-foreground">{g.description}</span>
              </motion.div>
            ))}
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onDismiss}
            className="mt-6 w-full kiddo-btn kiddo-gradient-sky text-primary-foreground text-lg py-3"
          >
            Got it! Let's go! 🚀
          </motion.button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default GestureTutorial;
