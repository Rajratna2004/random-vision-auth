-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Anyone can manage achievements" ON public.achievements;
DROP POLICY IF EXISTS "Anyone can manage profiles" ON public.player_profiles;
DROP POLICY IF EXISTS "Anyone can insert game sessions" ON public.game_sessions;
DROP POLICY IF EXISTS "Anyone can read game sessions" ON public.game_sessions;

-- Achievements: owner-scoped policies
CREATE POLICY "Users can read own achievements"
  ON public.achievements FOR SELECT
  TO authenticated
  USING (player_id = auth.uid()::text);

CREATE POLICY "Users can insert own achievements"
  ON public.achievements FOR INSERT
  TO authenticated
  WITH CHECK (player_id = auth.uid()::text);

CREATE POLICY "Users can delete own achievements"
  ON public.achievements FOR DELETE
  TO authenticated
  USING (player_id = auth.uid()::text);

-- Game sessions: owner-scoped policies
CREATE POLICY "Users can insert own game sessions"
  ON public.game_sessions FOR INSERT
  TO authenticated
  WITH CHECK (player_id = auth.uid()::text);

CREATE POLICY "Users can read own game sessions"
  ON public.game_sessions FOR SELECT
  TO authenticated
  USING (player_id = auth.uid()::text);

-- Player profiles: owner-scoped policies
CREATE POLICY "Users can read own profile"
  ON public.player_profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid()::text);

CREATE POLICY "Users can insert own profile"
  ON public.player_profiles FOR INSERT
  TO authenticated
  WITH CHECK (id = auth.uid()::text);

CREATE POLICY "Users can update own profile"
  ON public.player_profiles FOR UPDATE
  TO authenticated
  USING (id = auth.uid()::text)
  WITH CHECK (id = auth.uid()::text);