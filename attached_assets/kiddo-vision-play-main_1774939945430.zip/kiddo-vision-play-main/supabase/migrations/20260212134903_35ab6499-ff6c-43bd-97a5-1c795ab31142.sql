
-- Game progress tracking (anonymous - no auth required for kids)
CREATE TABLE public.game_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_id TEXT NOT NULL DEFAULT 'default',
  game_type TEXT NOT NULL,
  score INTEGER NOT NULL DEFAULT 0,
  moves INTEGER,
  duration_seconds INTEGER,
  difficulty TEXT,
  completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Player profiles (anonymous, identified by local storage ID)
CREATE TABLE public.player_profiles (
  id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL DEFAULT 'Player',
  total_stars INTEGER NOT NULL DEFAULT 0,
  current_streak INTEGER NOT NULL DEFAULT 0,
  last_played_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Achievements
CREATE TABLE public.achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_id TEXT NOT NULL,
  achievement_key TEXT NOT NULL,
  unlocked_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(player_id, achievement_key)
);

-- Enable RLS
ALTER TABLE public.game_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.player_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;

-- Public access policies (kid-friendly, no auth required)
CREATE POLICY "Anyone can insert game sessions" ON public.game_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can read game sessions" ON public.game_sessions FOR SELECT USING (true);

CREATE POLICY "Anyone can manage profiles" ON public.player_profiles FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Anyone can manage achievements" ON public.achievements FOR ALL USING (true) WITH CHECK (true);
