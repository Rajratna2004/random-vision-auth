import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate JWT and get authenticated user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseAuth = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseAuth.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const playerId = user.id;

    // Use service role to fetch data (scoped to authenticated user's ID)
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: sessions } = await supabase
      .from("game_sessions")
      .select("*")
      .eq("player_id", playerId)
      .order("created_at", { ascending: false });

    const total = sessions?.length || 0;
    const completed = sessions?.filter((s: any) => s.completed).length || 0;
    const totalTime =
      sessions?.reduce(
        (sum: number, s: any) => sum + (s.duration_seconds || 0),
        0
      ) || 0;

    const byGame: Record<string, number> = {};
    sessions?.forEach((s: any) => {
      byGame[s.game_type] = (byGame[s.game_type] || 0) + 1;
    });

    return new Response(
      JSON.stringify({
        player_id: playerId,
        total_sessions: total,
        completed_sessions: completed,
        total_time_seconds: totalTime,
        games_by_type: byGame,
        recent_sessions: sessions?.slice(0, 10) || [],
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
